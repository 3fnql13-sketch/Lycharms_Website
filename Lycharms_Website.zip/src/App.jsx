import React from "react";
import { motion } from "framer-motion";
import LycharmsOnePage from "./LycharmsOnePage";

export default function App(){
  return <LycharmsOnePage />;
}